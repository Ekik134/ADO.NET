using Dapper;
using TaskTracker.Data;
using TaskTracker.Models;

namespace TaskTracker.Repositories;

public class ProjectRepository
{
    private readonly IDbConnectionFactory _factory;

    public ProjectRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<Project> CreateAsync(
        string name, int ownerId, string[] tags, string settingsJson)
    {
        using var conn = _factory.Create();

        return await conn.QuerySingleAsync<Project>(@"
            INSERT INTO projects (name, owner_id, tags, settings)
            VALUES (@Name, @OwnerId, @Tags, @Settings::jsonb)
            RETURNING *",
            new { Name = name, OwnerId = ownerId, Tags = tags, Settings = settingsJson });
    }

    public async Task<List<Project>> GetByTagAsync(string tag)
    {
        using var conn = _factory.Create();

        // Поиск по массиву через ANY
        return (await conn.QueryAsync<Project>(
            "SELECT * FROM projects WHERE @Tag = ANY(tags) ORDER BY id",
            new { Tag = tag })).ToList();
    }

    // JOIN проекта с задачами — один-ко-многим с ручной группировкой
    public async Task<Project?> GetWithTasksAsync(int projectId)
    {
        using var conn = _factory.Create();

        var dict = new Dictionary<int, Project>();

        await conn.QueryAsync<Project, TaskItem, Project>(@"
            SELECT p.id, p.name, p.owner_id, p.tags, p.settings, p.created_at,
                   t.id, t.project_id, t.title, t.is_done, t.due_date, t.metadata, t.created_at
            FROM projects p
            LEFT JOIN tasks t ON t.project_id = p.id
            WHERE p.id = @Id
            ORDER BY p.id, t.id",
            (project, task) =>
            {
                if (!dict.TryGetValue(project.Id, out var current))
                {
                    current = project;
                    current.Tasks = new List<TaskItem>();
                    dict.Add(current.Id, current);
                }

                if (task is not null && task.Id != 0)
                    current.Tasks.Add(task);

                return current;
            },
            new { Id = projectId },
            splitOn: "id");

        return dict.Values.FirstOrDefault();
    }

    // Пагинация через QueryMultiple
    public async Task<(List<Project> Items, int Total)> GetPageAsync(int page, int pageSize)
    {
        using var conn = _factory.Create();
        var offset = (page - 1) * pageSize;

        using var multi = await conn.QueryMultipleAsync(@"
            SELECT COUNT(*) FROM projects;
            SELECT * FROM projects ORDER BY id LIMIT @Limit OFFSET @Offset;",
            new { Limit = pageSize, Offset = offset });

        var total = await multi.ReadSingleAsync<int>();
        var items = (await multi.ReadAsync<Project>()).ToList();

        return (items, total);
    }

    public async void UpdateSettingsAsync(int id, string jsonPatch)
    {
        using var conn = _factory.Create();

        await conn.ExecuteAsync(@"
            UPDATE events
            SET payload = settings || @Patch::jsonb
            WHERE id = @Id",
            new { Id = id, Patch = jsonPatch }
        );
    }
}